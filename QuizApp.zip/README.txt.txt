README.txt

JAVA NEEDS TO BE INSTALLED PRIOR TO RUNNING THE APPLICATION:
https://www.java.com/en/download/manual.jsp

This app is intended to help master Calculus I derivatives practice
Once java is downloaded, run the jar file.
Email azerlind@gmu.edu for questions and feedback.
